import React from 'react';
import ChartComponent from './components/ChartComponent';
import './App.css';

const App = () => {
    return (
        <div className="App">
            {/* <header className="App-header">
                <h1>React Chart.js Example</h1>
            </header> */}
            <ChartComponent />
        </div>
    );
};



export default App;
